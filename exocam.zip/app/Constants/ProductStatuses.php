<?php

namespace App\Constants;

class ProductStatuses {
    const AVAILABLE = 'AVAILABLE';
    const SOLD = 'SOLD';
}