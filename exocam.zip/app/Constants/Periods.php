<?php

namespace App\Constants;

class Periods {
    const DAY = 'DAY';
    const MONTH = 'MONTH';
    const YEAR = 'YEAR';
    const YESTERDAY = 'YESTERDAY';
    const LASTMONTH = 'LASTMONTH';
    const LASTYEAR = 'LASTYEAR';
}