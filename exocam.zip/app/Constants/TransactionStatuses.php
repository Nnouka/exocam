<?php

namespace App\Constants;

class TransactionStatuses {
    const POSTED = 'POSTED';
    const PENDING = 'PENDING';
}