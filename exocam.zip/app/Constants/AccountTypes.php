<?php

namespace App\Constants;

class AccountTypes {
    const INVENTORY = 'INVENTORY';
    const PURCHASE = 'PURCHASE';
    const SALES = 'SALES';
    const CASH = 'CASH';
}