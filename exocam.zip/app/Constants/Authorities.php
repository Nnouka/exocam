<?php
namespace App\Constants;

class Authorities {
    const ADMIN = 'ADMIN';
    const STUDENT = 'STUDENT';
    const MENTOR = 'MENTOR';
}
