<?php

namespace App\Constants;

class TransactionMotives {
    const SALE = 'SALE';
    const PURCHASE = 'PURCHASE';
}