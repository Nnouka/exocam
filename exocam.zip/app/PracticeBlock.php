<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PracticeBlock extends Model
{
    //
}
