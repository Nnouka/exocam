import React from 'react';

function Welcome(props) {
    return (
        <div>Welcome</div>
    );
}

export default Welcome;