import React from 'react';

function Home(props) {
    return (
        <div>Home</div>
    );
}

export default Home;